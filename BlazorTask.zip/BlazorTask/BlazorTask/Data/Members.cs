﻿namespace BlazorTask.Data
{
    public class Members
    {
        //each element in emails list has its password in the corresponding passwords list
        // i.e emails[1] has password[1]
        public List<string> emails = new List<string>() {"emp1@Lazord.org", "emp2@Lazord.org","google@gmail.com","bing@outlook.com"};
        public List<string> passwords = new List<string>() {"emp12345", "emp2345","googleisthebest","bingisthebest"};
    }
}
