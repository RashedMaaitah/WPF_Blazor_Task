﻿using System.Windows;

namespace WPFTask
{
	/// <summary>
	/// Interaction logic for ForgotPassword.xaml
	/// </summary>
	public partial class ForgotPassword : Window
	{
		Data.Members members = new Data.Members();
		public ForgotPassword()
		{
			InitializeComponent();
		}

		private void Verify(object sender, RoutedEventArgs e)
		{
			sent.Visibility = Visibility.Hidden;
			wrongEmail.Visibility = Visibility.Hidden;
			if (members.emails.Contains(UserName.Text))
			{
				sent.Visibility = Visibility.Visible;
				MessageBox.Show("Code sent.");
				//this.Close();
			}
			else
			{
				wrongEmail.Visibility = Visibility.Visible;
			}
		}
	}
}
