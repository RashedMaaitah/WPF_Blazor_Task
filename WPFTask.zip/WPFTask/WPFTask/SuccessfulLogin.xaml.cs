﻿using System.Windows;

namespace WPFTask
{
	/// <summary>
	/// Interaction logic for SuccessfulLogin.xaml
	/// </summary>
	public partial class SuccessfulLogin : Window
	{
		public SuccessfulLogin()
		{
			InitializeComponent();
		}
	}
}
