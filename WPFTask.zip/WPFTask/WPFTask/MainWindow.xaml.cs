﻿using System.Windows;

namespace WPFTask
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		Data.Members members = new Data.Members();
		
		public MainWindow()
		{
			InitializeComponent();
		}
		
		private void Button_Click(object sender, RoutedEventArgs e)
		{
			string userEmail = EmailBox.Text;
			string userPass = PasswordBox.Password;
			if(members.emails.Contains(userEmail) )
			{
				EmailNotFound.Visibility = Visibility.Hidden;
				if (members.passwords.Contains(userPass) )
				{
					WrongPass.Visibility = Visibility.Hidden;
					SuccessfulLogin navigatesWindow = new();
					navigatesWindow.ShowDialog();
				}
				else
				{
					//if the password is wrong 
					
					WrongPass.Visibility = Visibility.Visible; 
				}
			}
			else
			{
				//if the email doesnt exists
				EmailNotFound.Visibility = Visibility.Visible;
			}
			
		
		}

		private void forgotpassword_Click(object sender, RoutedEventArgs e)
		{
			ForgotPassword forgot = new ForgotPassword();
			forgot.ShowDialog();
		}
	}
}
